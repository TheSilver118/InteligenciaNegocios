from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pandas as pd
import joblib
import os

app = FastAPI(title="API Cripto")

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model", "modelo_clustering.pkl")
DATA_PATH = os.path.join(BASE_DIR, "data", "criptomonedas_crypto_compare.csv")

# Cargar modelo y datos
try:
    model = joblib.load(MODEL_PATH)
except Exception as e:
    model = None

try:
    df = pd.read_csv(DATA_PATH)
    df["cluster"] = model.predict(df[["open", "high", "low", "close", "volumeto"]])
except Exception as e:
    df = None

# Esquema de entrada
class InvestmentProfile(BaseModel):
    open: float
    high: float
    low: float
    close: float
    volumeto: float

# Endpoint de salud
@app.get("/health")
def health():
    return {
        "model_loaded": model is not None,
        "data_loaded": df is not None
    }

# Endpoint de predicción
@app.post("/predict")
def predict(profile: InvestmentProfile):
    if model is None:
        raise HTTPException(status_code=500, detail="Modelo no disponible")

    X = pd.DataFrame([profile.dict()])
    try:
        cluster = int(model.predict(X)[0])
        return {
            "cluster": cluster,
            "description": f"Perfil clasificado en el clúster {cluster}"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Error en la predicción")

# Endpoint de recomendaciones
@app.get("/recommendations")
def recommendations(cluster: int, top_n: int = 5):
    if df is None or "cluster" not in df.columns:
        raise HTTPException(status_code=500, detail="Datos no disponibles")

    subset = df[df["cluster"] == cluster]
    if subset.empty:
        return {"cluster": cluster, "detalle": {}}

    top = (
        subset.groupby("coin")["close"]
        .mean()
        .sort_values(ascending=False)
        .head(top_n)
    )
    return {
        "cluster": cluster,
        "detalle": top.to_dict()
    }
