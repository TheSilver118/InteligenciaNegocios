import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import numpy as np

API_URL = "http://127.0.0.1:8000"

st.set_page_config(page_title="Dashboard Cripto", layout="wide")
st.title(" Dashboard de Recomendación de Criptomonedas")
st.caption("Interfaz visual que consume la API de clustering y recomendaciones de FastAPI.")

# -----------------------------
# Utilidades HTTP contra la API
# -----------------------------
def api_post(path, payload):
    try:
        r = requests.post(f"{API_URL}{path}", json=payload, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f" Error POST {path}: {e}")
        return None

def api_get(path, params=None):
    try:
        r = requests.get(f"{API_URL}{path}", params=params, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        st.error(f" Error GET {path}: {e}")
        return None

# -----------------------------
# Sidebar: entrada de perfil
# -----------------------------
with st.sidebar:
    st.header("🔍 Predicción del perfil de inversión")
    preset = st.selectbox("Preset de ejemplo", ["Personalizado", "BTC Alta", "ETH Media", "SOL Dinámica"])

    presets = {
        "BTC Alta": [50000, 51500, 49000, 50500, 1500000],
        "ETH Media": [2300, 2400, 2250, 2350, 800000],
        "SOL Dinámica": [80, 95, 70, 86, 1200000],
        "Personalizado": [50000, 51000, 49000, 50500, 1000000]
    }

    open_val, high_val, low_val, close_val, volumeto_val = presets[preset]

    with st.form("perfil_form"):
        open_in = st.number_input("Open", value=open_val)
        high_in = st.number_input("High", value=high_val)
        low_in = st.number_input("Low", value=low_val)
        close_in = st.number_input("Close", value=close_val)
        volumeto_in = st.number_input("VolumeTo", value=volumeto_val)
        use_manual = st.checkbox("Seleccionar clúster manualmente")
        manual_cluster = st.number_input("Clúster manual", min_value=0, value=0, step=1, disabled=not use_manual)
        submitted = st.form_submit_button("Analizar perfil e iniciar búsqueda")

# -----------------------------
# Tabs
# -----------------------------
tab_pred, tab_rec, tab_stats, tab_signals, tab_hist = st.tabs([
    "🔮 Predicción", "📊 Recomendaciones", "📈 Estadísticas por Clúster", "🧭 Señales por Moneda", "🕰 Historial"
])

if "last_cluster" not in st.session_state:
    st.session_state["last_cluster"] = None

# -----------------------------
# Tab: Predicción
# -----------------------------
with tab_pred:
    if submitted:
        if use_manual:
            st.session_state["last_cluster"] = int(manual_cluster)
            st.info(f"Clúster seleccionado manualmente: {manual_cluster}")
        else:
            payload = {
                "open": open_in, "high": high_in, "low": low_in,
                "close": close_in, "volumeto": volumeto_in
            }
            result = api_post("/predict", payload)
            if result:
                cluster = result.get("cluster")
                st.session_state["last_cluster"] = cluster
                st.success(f"✅ Perfil clasificado: Clúster {cluster}")
                st.markdown(f"🧠 Descripción: {result.get('description', 'Sin descripción')}")
            else:
                st.error("No se pudo clasificar el perfil.")

# -----------------------------
# Tab: Recomendaciones
# -----------------------------
with tab_rec:
    cluster = st.session_state["last_cluster"]
    if cluster is None:
        st.info("Primero clasifica un perfil o selecciona clúster manual.")
    else:
        st.subheader(f"Recomendaciones para el Clúster {cluster}")
        recs = api_get("/recommendations", params={"cluster": cluster, "top_n": 5})

        if recs and recs.get("detalle"):
            detalle = recs["detalle"]
            if isinstance(detalle, dict) and len(detalle) > 0:
                s = pd.Series(detalle).sort_values(ascending=False)
                df_recs = s.reset_index()
                df_recs.columns = ["Criptomoneda", "Cierre Promedio ($)"]
                df_recs["Clúster"] = f"Clúster {cluster}"

                st.dataframe(df_recs.style.format({"Cierre Promedio ($)": "${:,.2f}"}), use_container_width=True)

                fig = px.bar(
                    df_recs,
                    x="Criptomoneda",
                    y="Cierre Promedio ($)",
                    color="Criptomoneda",
                    title=f"Top criptomonedas por cierre promedio en Clúster {cluster}",
                    template="plotly_dark"
                )
                fig.update_layout(showlegend=False)
                st.plotly_chart(fig, use_container_width=True)

                mejor_crypto = df_recs.iloc[0]["Criptomoneda"]
                mejor_valor = df_recs.iloc[0]["Cierre Promedio ($)"]
                st.success(
                    f"💡 Recomendación: Según tu perfil en el Clúster {cluster}, "
                    f"la criptomoneda más destacada es **{mejor_crypto}** "
                    f"con un cierre promedio de ${mejor_valor:,.2f}."
                )

                st.download_button(
                    " Descargar recomendaciones",
                    data=df_recs.to_csv(index=False).encode("utf-8"),
                    file_name=f"recomendaciones_cluster_{cluster}.csv",
                    mime="text/csv"
                )
            else:
                st.warning("No hay datos disponibles para este clúster.")
        else:
            st.warning("No se obtuvieron recomendaciones para este clúster.")

# -----------------------------
# Tab: Estadísticas por Clúster
# -----------------------------
with tab_stats:
    st.subheader("📈 Estadísticas por Clúster")

    try:
        df_stats = pd.read_csv("data/criptomonedas_crypto_compare.csv")
    except Exception as e:
        st.error(f"No se pudo cargar el CSV: {e}")
        df_stats = None

    if df_stats is not None:
        required_cols = {"open", "high", "low", "close", "volumeto", "coin"}
        if not required_cols.issubset(df_stats.columns):
            st.warning(f"El dataset debe tener columnas: {sorted(required_cols)}")
        elif "cluster" not in df_stats.columns:
            st.warning("El dataset no tiene columna 'cluster'.")
        else:
            # 1) Cantidad de registros por criptomoneda en cada clúster
            count_df = df_stats.groupby(["cluster", "coin"]).size().reset_index(name="count")
            fig1 = px.bar(
                count_df, x="coin", y="count", color="cluster",
                title="Cantidad de registros por criptomoneda en cada clúster",
                labels={"coin": "Criptomoneda", "count": "Cantidad", "cluster": "Clúster"},
                barmode="group", template="plotly_dark"
            )
            st.plotly_chart(fig1, use_container_width=True)

            # 2) Boxplot: distribución del precio de cierre por criptomoneda
            fig2 = px.box(
                df_stats, x="coin", y="close", color="coin",
                title="Distribución del precio de cierre por criptomoneda",
                labels={"coin": "Criptomoneda", "close": "Precio de cierre"},
                template="plotly_dark"
            )
            st.plotly_chart(fig2, use_container_width=True)

            # 3) Dispersión: volumen vs cierre, coloreado por clúster
            fig3 = px.scatter(
                df_stats, x="volumeto", y="close", color="cluster", symbol="coin",
                title="Relación entre volumen y precio de cierre por clúster",
                labels={"volumeto": "Volumen", "close": "Precio de cierre", "cluster": "Clúster"},
                template="plotly_dark"
            )
            st.plotly_chart(fig3, use_container_width=True)

            # Análisis automático
            st.markdown("🔎 **Análisis automático:**")
            top_coin = df_stats.groupby("coin")["close"].mean().sort_values(ascending=False).index[0]
            avg_vol = df_stats["volumeto"].mean()
            avg_range = (df_stats["high"] - df_stats["low"]).mean()

            st.markdown(
                f"- **Mayor cierre promedio:** {top_coin}\n"
                f"- **Volumen promedio:** {avg_vol:,.0f} → perfil {'agresivo' if avg_vol > 1_000_000 else 'moderado'}\n"
                f"- **Rango diario promedio:** ${avg_range:,.2f} → volatilidad {'alta' if avg_range > 500 else 'baja'}"
            )

# -----------------------------
# Tab: Señales por Moneda
# -----------------------------
with tab_signals:
    st.subheader("🧭 Señales por Moneda (comprar, vender, mantener)")

    try:
        df_all = pd.read_csv("data/criptomonedas_crypto_compare.csv")
    except Exception as e:
        st.error(f"No se pudo cargar el CSV: {e}")
        df_all = None

    if df_all is not None:
        required_cols = {"time", "open", "high", "low", "close", "volumeto", "coin"}
        if not required_cols.issubset(df_all.columns):
            st.warning(f"El CSV debe contener columnas: {sorted(required_cols)}")
        else:
            monedas = sorted(df_all["coin"].unique().tolist())
            moneda = st.selectbox("Selecciona una criptomoneda", monedas, index=0)
            df = df_all[df_all["coin"] == moneda].copy()
            df["time"] = pd.to_datetime(df["time"], errors="coerce")
            df = df.dropna(subset=["time"]).sort_values("time").reset_index(drop=True)

            col_a, col_b, col_c = st.columns(3)
            with col_a:
                window_ma_short = st.number_input("Media móvil corta (MA)", min_value=5, max_value=50, value=20)
            with col_b:
                window_ma_long = st.number_input("Media móvil larga (MA)", min_value=20, max_value=200, value=50)
            with col_c:
                rsi_window = st.number_input("Ventana RSI", min_value=7, max_value=30, value=14)

            # Medias móviles
            df["ma_short"] = df["close"].rolling(window_ma_short).mean()
            df["ma_long"] = df["close"].rolling(window_ma_long).mean()

            # RSI (Wilder)
            delta = df["close"].diff()
            gain = np.where(delta > 0, delta, 0.0)
            loss = np.where(delta < 0, -delta, 0.0)
            roll_up = pd.Series(gain).rolling(rsi_window).mean()
            roll_down = pd.Series(loss).rolling(rsi_window).mean()
            rs = roll_up / (roll_down + 1e-12)
            df["rsi"] = 100 - (100 / (1 + rs))

            # Soportes y resistencias (lookback configurable)
            lookback = st.slider("Lookback para soportes/resistencias", min_value=20, max_value=200, value=60, step=10)
            df_tail = df.tail(lookback)
            soporte = float(df_tail["low"].min())
            resistencia = float(df_tail["high"].max())

            # Precio actual e indicadores
            if len(df) == 0 or df["close"].isna().all():
                st.warning("Sin datos suficientes para esta moneda.")
            else:
                precio_actual = float(df["close"].iloc[-1])
                ma_s = float(df["ma_short"].iloc[-1]) if not np.isnan(df["ma_short"].iloc[-1]) else None
                ma_l = float(df["ma_long"].iloc[-1]) if not np.isnan(df["ma_long"].iloc[-1]) else None
                rsi_last = float(df["rsi"].iloc[-1]) if not np.isnan(df["rsi"].iloc[-1]) else None

                def near_level(price, level, pct=0.02):
                    return abs(price - level) / max(price, 1e-12) <= pct

                signals = []
                if (ma_s is not None) and (ma_l is not None) and (rsi_last is not None):
                    if (ma_s > ma_l) and (rsi_last < 35) and near_level(precio_actual, soporte, 0.03):
                        accion = "🟢 Comprar"
                        signals.append("Cruce alcista de medias, RSI bajo, cerca del soporte.")
                    elif (ma_s < ma_l) and (rsi_last > 65) and near_level(precio_actual, resistencia, 0.03):
                        accion = "🔴 Vender"
                        signals.append("Cruce bajista de medias, RSI alto, cerca de la resistencia.")
                    else:
                        accion = "🟡 Mantener"
                        signals.append("Sin señal clara: conservar o esperar mejor entrada.")
                else:
                    accion = "⚪ Señal no concluyente"
                    signals.append("Indicadores insuficientes o ventanas muy largas para los datos disponibles.")

                st.markdown(f"### Recomendación para {moneda}")
                met1, met2, met3, met4 = st.columns(4)
                met1.metric("Precio actual", f"${precio_actual:,.2f}")
                met2.metric(f"MA {window_ma_short}", "-" if ma_s is None else f"${ma_s:,.2f}")
                met3.metric(f"MA {window_ma_long}", "-" if ma_l is None else f"${ma_l:,.2f}")
                met4.metric("RSI", "-" if rsi_last is None else f"{rsi_last:,.1f}")

                st.info(f"Soporte estimado: ${soporte:,.2f} | Resistencia: ${resistencia:,.2f}")
                st.success(f"Acción sugerida: {accion}")
                st.markdown("**Razonamiento:** " + " ".join(signals))

                # Gráfico: precio + medias + niveles
                fig_price = px.line(
                    df.tail(200), x="time", y=["close", "ma_short", "ma_long"],
                    labels={"value": "Precio", "time": "Fecha"},
                    title=f"Precio y medias móviles — {moneda}",
                    template="plotly_dark"
                )
                fig_price.add_hline(y=soporte, line_dash="dot", line_color="green", annotation_text="Soporte")
                fig_price.add_hline(y=resistencia, line_dash="dot", line_color="red", annotation_text="Resistencia")
                st.plotly_chart(fig_price, use_container_width=True)

                # Gráfico: RSI
                fig_rsi = px.line(
                    df.tail(200), x="time", y="rsi",
                    labels={"rsi": "RSI", "time": "Fecha"},
                    title=f"RSI — {moneda}",
                    template="plotly_dark"
                )
                fig_rsi.add_hline(y=70, line_dash="dash", line_color="red", annotation_text="Sobrecompra")
                fig_rsi.add_hline(y=30, line_dash="dash", line_color="green", annotation_text="Sobreventa")
                st.plotly_chart(fig_rsi, use_container_width=True)

                # Descarga de señales e indicadores
                out = df[["time", "open", "high", "low", "close", "volumeto", "ma_short", "ma_long", "rsi"]].tail(300)
                st.download_button(
                    "📥 Descargar serie e indicadores (CSV)",
                    data=out.to_csv(index=False).encode("utf-8"),
                    file_name=f"indicadores_{moneda}.csv",
                    mime="text/csv"
                )

# -----------------------------
# Tab: Historial
# -----------------------------
with tab_hist:
    st.subheader("Historial de búsquedas")
    hist = api_get("/history", params={"limit": 25})
    if hist and hist.get("items"):
        df_hist = pd.DataFrame(hist["items"])
        st.dataframe(df_hist, use_container_width=True)
        st.download_button(
            "📥 Exportar historial",
            data=df_hist.to_csv(index=False).encode("utf-8"),
            file_name="historial_predicciones.csv",
            mime="text/csv"
        )
    else:
        st.info("No hay historial disponible.")